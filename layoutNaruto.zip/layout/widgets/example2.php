<div class="sidebar">
	<h3>Useful Links</h3>
	<ul>
		<li><a href="#">First Link</a></li>
		<li><a href="#">Another Link</a></li>
		<li><a href="#">And Another</a></li>
		<li><a href="#">Last One</a></li>
	</ul>
</div>